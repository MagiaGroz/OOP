import java.util.Scanner;
public class task1 {


	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int a = scan.nextInt();
		System.out.println(a*4);
		System.out.println(a*a);
		System.out.println(Math.sqrt(a*a+a*a));
	}
	


}
