
public class task5 {
	public static void main(String[] args) {
		
		int initial = 100;
		int inter=10;
		double newbalance= initial + (initial/100)*inter;
		System.out.println(newbalance);
		
	}
	

}