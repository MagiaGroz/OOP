
public enum Color {
BLACK,RED
}
