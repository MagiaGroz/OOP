package lab2;

	

public class task1 {

	public static void main(String[] args) {
		Student s= new Student("Dauren", 213434);
		s.Name();
		s.id();
		s.Inc();
}
}
