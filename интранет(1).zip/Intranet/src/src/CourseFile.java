package src;
import java.util.*;

/**
 * @see new value
 */
public class CourseFile {
    /**
     */
    private Vector<String> files;

    /**
     * @return 
     */
    public Collection getLab() {
        return null;
    }

    /**
     * @param lab 
     */
    public void setLab(Collection lab) {
    }
}

