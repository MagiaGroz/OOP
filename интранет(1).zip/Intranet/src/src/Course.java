package src;
import java.lang.*;
import java.util.*;


/**
 * @see new value
 */
public class Course {
    /**
     */
    private String name;

    /**
     */
    private CourseFile file;

    /**
     */
    private String textbook;

    /**
     */
    private boolean openReg;

    /**
     */
    private Collection students;
}

