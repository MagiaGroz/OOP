package src;
import java.lang.*;

/**
 */
public class Invalid_sort_parameter {
    /**
     * @param message 
     */
    public Invalid_sort_parameter(String message) {
    }

    /**
     * @param cause 
     * @param message 
     */
    public Invalid_sort_parameter(String message, Throwable cause) {
    }
}

