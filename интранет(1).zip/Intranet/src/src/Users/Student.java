package src.Users;

import java.lang.*;
import java.util.HashMap;

import src.Course;
import src.Mark;

/**
 */
public class Student extends User {
	public Student(String login, String password){
    	super(login,password);
    }
    private String name;

    /**
     * @see new value
     */
    private HashMap<Course, Mark> crsmark;

    /**
     */
    private Faculty dep;

    /**
     * @param crs 
     */
    public void viewMark(Course crs) {
    }

    /**
     * @param crs 
     */
    public void regCourse(int crs) {
    }

    /**
     */
    public void viewFiles() {
    }

    /**
     * @return 
     */
    public String viewInfoTeacher() {
        return null;
    }

    /**
     */
    public void viewTranscript() {
    }
}

