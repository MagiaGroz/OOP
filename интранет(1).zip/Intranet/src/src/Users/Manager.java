package src.Users;

import java.util.*;

import src.Course;

import java.lang.*;

/**
 */
public class Manager extends Employee {
	public Manager(String login, String password){
    	super(login,password);
    }
    private static Collection coursedb;

    /**
     * @param crs 
     */
    public void OpenCrsReg(Course crs) {
    }

    /**
     */
    public void SendMessage() {
    }

    /**
     * @return 
     */
    public String viewInfoUser() {
        return null;
    }

    /**
     * @param description 
     */
    public void sendOrder(String description) {
    }
}

