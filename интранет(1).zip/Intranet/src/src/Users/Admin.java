package src.Users;

import src.Systems;


public class Admin extends User {
    public Admin(String login, String password) {
		super(login, password);
		// TODO Auto-generated constructor stub
	}

	
    public static void addUser(User u) {
    	Systems.usersdb.add(u);
    }

  
    public static void removeUser(User u) {
    	Systems.usersdb.remove(u);
    }

    
    public void updateUser() {
    	
    }

   
    public static String seeLog() {
    	return "";
    }
}

