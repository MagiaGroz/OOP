package src.Users;

import java.util.*;
import java.lang.*;
import src.Course;

/**
 */
public class Teacher extends Employee {
	public Teacher(String login, String password){
    	super(login,password);
    }
    private Collection courses;

    /**
     */
    private Vector<String> message;

    /**
     * @param crs 
     */
    public void addCourse(Course crs) {
    }

    /**
     * @param param1 
     * @param param2 
     */
    public void putMark(Student param1, Course param2) {
    }

    /**
     */
    public void manageCourses() {
    }

    /**
     * @param crs 
     */
    public void viewStudents(Course crs) {
    }

    /**
     * @return 
     */
    public String report() {
        return null;
    }

    /**
     * @return 
     */
    public String getMessage() {
        return null;
    }

    /**
     * @param message 
     */
    public void setMessage(String message) {
    }

    /**
     * @param description 
     */
    public void sendOrder(String description) {
    }
}

