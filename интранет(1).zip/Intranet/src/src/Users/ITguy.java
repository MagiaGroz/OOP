package src.Users;

import java.util.Vector;

import src.Order;

/**
 */
public class ITguy extends Employee {
	public ITguy(String login, String password){
    	super(login,password);
    }
    private static Vector<Order> orders;

    /**
     */
    public void viewOrders() {
    }

    /**
     */
    public void viewAccepted() {
    }
}

