package src.Users;
import java.lang.*;

/**
 */
public class Faculty {
    /**
     */
    private String FIT;

    /**
     */
    private String FEOGI;

    /**
     */
    private String ISE;

    /**
     */
    private String BS;

    /**
     */
    private String KMA;

    /**
     */
    private String SOMAC;

    /**
     */
    private String CCE;
}

