package src;
import java.lang.*;

/**
 */
public class Order {
    /**
     * @see new value
     */
    private boolean isNew;

    /**
     * @see new value
     */
    private boolean isDone;

    /**
     * @see new value
     */
    private String description;
}

