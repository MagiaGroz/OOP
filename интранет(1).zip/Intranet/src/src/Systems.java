package src;
import java.util.*;

import src.Users.Admin;
import src.Users.ITguy;
import src.Users.Manager;
import src.Users.Student;
import src.Users.Teacher;
import src.Users.User;
import src.Users.Employee;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.sql.Time;
import java.time.LocalDateTime;


public class Systems {
   	Vector<String> s;
    public static Vector<User> usersdb = new Vector<User>();
    
	 public static void main(String[] args) throws IOException, InvalidLogException {
		 Admin t = new Admin("Hinam","123");
		 Systems.usersdb.add(t);
		 
			BufferedReader reader = new BufferedReader(new InputStreamReader(System.in)); // ������ ��� ������ � �������	

		 main:while(true) {
		 System.out.println("Enter your login");
		 String log = reader.readLine();
		 System.out.println("Enter your password");
		 String pass = reader.readLine();
		 
		 if(authentification(log,pass) instanceof Admin) {
			 
					System.out.println("Welcome!");
					menu : while(true){
						System.out.println("What do you want to do?");
						System.out.println("\n 1) Add User \n 2) Remove User  \n 3) Add course to a Student  \n 4) View students \n 5) Exit");
						int choice = reader.read()-48;
					//	System.err.println(choice);
						if(choice==1){
							addUser: while(true){
								System.out.println("Enter login for him: ");
								String tempLog= reader.readLine();
								
								System.out.println("Enter password for him: ");
								String tempPass = reader.readLine();
							
								System.out.println("Enter type of User: ");
								String type = reader.readLine();
									switch(type) {
									case "Teacher": 
										Admin.addUser(new Teacher(tempLog,tempPass));
										break;
									case "Manager": 
										Admin.addUser(new Manager(tempLog,tempPass));
										break;
									case "Admin": 
										Admin.addUser(new Admin(tempLog,tempPass));
										break;
									case "ITguy": 
										Admin.addUser(new ITguy(tempLog,tempPass));
										break;
									case "Student": 
										Admin.addUser(new Student(tempLog,tempPass));
										break;
											
									}
							
								System.out.println("User added! ");
								writeUsingFiles(LocalDateTime.now() +" User with login "+tempLog+" and password: "+tempPass +"is added");
								System.out.println("\n 1) Add another User  \n 2) Return back \n 3) Exit");
								choice = reader.read()-48;
								if(choice==1) continue addUser;
								if(choice==2) continue menu;
								if(choice==3) {System.out.println("Bye!!!");  break main;}
								break;
							}
						}
						else if (choice==2){
							RemoveCourse: while(true){
								System.out.println("Enter login of User: ");
								String login = reader.readLine();
								for(int i=0;i<usersdb.size();i++) {
									if(usersdb.get(i).getlogin()==login)
										usersdb.remove(i);
								}
								System.out.println("User deleted! ");
								writeUsingFiles(LocalDateTime.now() +" User with login "+login+" is deleted");
								System.out.println("\n 1) Remove another user  \n 2) Return back \n 3) Exit");
								choice = reader.read();
								if(choice==1) continue RemoveCourse;
								if(choice==2) continue menu;
								if(choice==3) {System.out.println("Bye!!!");  break main;}
								break;
							}
						}
						
						else if (choice==5){
							System.out.println("Bye"); 
							
							break menu;
						}
					}
		 }
		 
		 //Other users
		 else {
			 //throw new InvalidLogException;
			 System.err.println("Invalid login or password");
			 continue;
		 }
		 }
		 }
	 
	 

			private static void writeUsingFiles(String data) {
		        try {
		            Files.write(Paths.get("src//log.txt"), data.getBytes(),StandardOpenOption.APPEND);
		       } catch (IOException e) {
		            e.printStackTrace();
		        }
		    } 
  
    public static User authentification(String log, String pass) {
    	for(int i=0;i<usersdb.size();i++) {
    		if(usersdb.get(i).getlogin().contentEquals(log)) {
    		if(usersdb.get(i).getpassword().contentEquals(pass)) {
    			return usersdb.get(i);
    		}
    		}
    	}
        return new ITguy("-1","-1");
    }



		class InvalidLogException extends Exception {
			private static final long serialVersionUID = -3329924916426778688L;
			public InvalidLogException() { super(); }
			  public InvalidLogException(String message) { super(message); }
			}
		
}