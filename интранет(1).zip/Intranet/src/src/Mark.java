package src;/**
 * @see Mark of course
 * @see new value
 * @see new value
*/
public class Mark {
/**
*/
private double att1;
/**
*/
private double att2;
/**
*/
private double finalMark;
/**
 * @return 
*/
public double overall() {
    return 0;
}
}

