package src;
import java.lang.*;

/**
 */
public class InvalidLoginOrPAssword {
    /**
     * @param message 
     */
    public InvalidLoginOrPAssword(String message) {
    }

    /**
     * @param cause 
     * @param message 
     */
    public InvalidLoginOrPAssword(String message, Throwable cause) {
    }
}

