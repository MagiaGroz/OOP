package lab5;

interface MyCollection{
	void add(Object e);
	void print();
	void clear();
	boolean contains(Object e);
	boolean IsEmpty();
	boolean remove(Object e);
	int size();
	Object getFirst();
	Object getLast();
}
public class Task3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
